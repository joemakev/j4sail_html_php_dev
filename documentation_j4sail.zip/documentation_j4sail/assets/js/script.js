/* 
---------------------------------
Common Functions and Snippets
---------------------------------
*/
/*
Return the visible amount of px of any element currently in viewport.
Sample:
    $(elem).inViewport(function(px) {
        if(px >= targetPx && !$(this).hasClass('animated')) {
            //
        }
    });
*/
(function($, win) {
    $.fn.inViewport = function(cb) {
        return this.each(function(i,el){
            function visPx(){
            var H = $(this).height(),
                r = el.getBoundingClientRect(), t=r.top, b=r.bottom;
            return cb.call(el, Math.max(0, t>0? H-t : (b<H?b:H)));  
            } visPx();
            $(win).on("resize scroll", visPx);
        });
    };
}(jQuery, window));


jQuery(document).ready(function() {
console.log('--> script.js');

$('#navDoc li a').click(function(e) {
    e.preventDefault();
    var targetId = $(this).attr('href');

    // $('#navDoc li').removeClass('active');
    // $(this).parent('li').addClass('active');

    $('html, body').animate({
        scrollTop: $(targetId).offset().top
    }, 500);
});

$('#main .content .partBox').inViewport(function(px) {
    if(px >= 300) {
        var targetId = '#'+$(this).attr('id');
        var targetElem = $('#navDoc li a[href="'+targetId+'"]');
        $('#navDoc li').removeClass('active');
        targetElem.parent('li').addClass('active');
    }
});

}); //jQuery(document).ready

